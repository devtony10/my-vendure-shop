export type DoordashConfigState = undefined | null | 'new' | 'saved';

export type DoordashConfigStatus = 'default' | 'checking'| 'failed'| 'success';