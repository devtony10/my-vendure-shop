export const DOORDASH_PLUGIN_OPTIONS = Symbol('DOORDASH_PLUGIN_OPTIONS');
export const loggerCtx = 'DoordashPlugin';
